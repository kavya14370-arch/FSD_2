const Item = require('../models/Item');
const { MATCH_THRESHOLD } = require('../config/constants');

// Weights add up to 100
const WEIGHTS = { category: 25, location: 25, date: 20, color: 15, keywords: 15 };

const STOP_WORDS = new Set(['the', 'and', 'for', 'with', 'was', 'has', 'have', 'had', 'this', 'that', 'from', 'near', 'found', 'lost', 'item', 'its', 'are', 'but', 'not', 'you', 'your', 'one', 'left', 'some', 'there', 'into']);

const tokenize = (text = '') =>
  text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP_WORDS.has(w));

// 1 within a day, falling linearly to 0 at 14 days apart
function dateScore(a, b) {
  const days = Math.abs(new Date(a) - new Date(b)) / 86400000;
  if (days <= 1) return 1;
  if (days >= 14) return 0;
  return 1 - (days - 1) / 13;
}

// exact = 1, "dark blue" vs "blue" (any shared color word) = 0.7, otherwise 0
function colorScore(a = '', b = '') {
  const x = a.trim().toLowerCase();
  const y = b.trim().toLowerCase();
  if (!x || !y) return 0;
  if (x === y) return 1;
  const xs = new Set(x.split(/[\s,/&-]+/));
  return y.split(/[\s,/&-]+/).some((w) => xs.has(w)) ? 0.7 : 0;
}

// share of the smaller keyword set that also appears in the other
function keywordScore(a, b) {
  const A = new Set(tokenize(`${a.title} ${a.description}`));
  const B = new Set(tokenize(`${b.title} ${b.description}`));
  if (!A.size || !B.size) return 0;
  let common = 0;
  A.forEach((w) => B.has(w) && common++);
  return common / Math.min(A.size, B.size);
}

function calculateMatch(a, b) {
  const parts = {
    category: a.category === b.category ? 1 : 0,
    location: a.location === b.location ? 1 : 0,
    date: dateScore(a.date, b.date),
    color: colorScore(a.color, b.color),
    keywords: keywordScore(a, b),
  };
  const breakdown = {};
  let total = 0;
  for (const key of Object.keys(WEIGHTS)) {
    breakdown[key] = Math.round(parts[key] * WEIGHTS[key] * 10) / 10;
    total += parts[key] * WEIGHTS[key];
  }
  return { score: Math.round(total), breakdown };
}

// Open items of the opposite type that resemble `item`, best first.
async function findMatches(item, { limit = 5, min = MATCH_THRESHOLD } = {}) {
  const candidates = await Item.find({
    _id: { $ne: item._id },
    type: item.type === 'LOST' ? 'FOUND' : 'LOST',
    status: { $in: ['OPEN', 'PENDING_CLAIM'] },
    postedBy: { $ne: item.postedBy },
    $or: [{ category: item.category }, { location: item.location }],
  }).populate('postedBy', 'name department');

  return candidates
    .map((c) => ({ item: c, ...calculateMatch(item, c) }))
    .filter((m) => m.score >= min)
    .sort((x, y) => y.score - x.score)
    .slice(0, limit);
}

module.exports = { calculateMatch, findMatches, WEIGHTS };
