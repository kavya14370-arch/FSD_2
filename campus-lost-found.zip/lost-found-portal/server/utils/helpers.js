const fs = require('fs');
const path = require('path');

exports.asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

exports.httpError = (status, message) => Object.assign(new Error(message), { status });

exports.escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Delete an uploaded image given its public path (/uploads/xyz.jpg). Never throws.
exports.removeImage = (publicPath) => {
  if (!publicPath || !publicPath.startsWith('/uploads/')) return;
  fs.unlink(path.join(__dirname, '..', publicPath), () => {});
};
