const Item = require('../models/Item');
const User = require('../models/User');
const { POINTS_PER_RETURN } = require('../config/constants');

// Closes a handover: marks the item returned and awards the finder points exactly once.
exports.finalizeReturn = async (ret) => {
  if (ret.pointsAwarded) return ret;
  ret.returnedDate = new Date();
  ret.pointsAwarded = true;
  await ret.save();
  await Item.findByIdAndUpdate(ret.itemId, { status: 'RETURNED' });
  await User.findByIdAndUpdate(ret.finderId, { $inc: { points: POINTS_PER_RETURN } });
  return ret;
};
