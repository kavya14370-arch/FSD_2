const router = require('express').Router();
const c = require('../controllers/returnController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/mine', c.myReturns);
router.put('/:id/confirm', c.confirmReturn);

module.exports = router;
