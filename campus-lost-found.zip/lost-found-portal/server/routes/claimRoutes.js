const router = require('express').Router();
const c = require('../controllers/claimController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.post('/', c.createClaim);
router.get('/mine', c.myClaims);
router.delete('/:id', c.withdrawClaim);

module.exports = router;
