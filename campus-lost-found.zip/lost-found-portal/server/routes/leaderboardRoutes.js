const router = require('express').Router();
const { leaderboard } = require('../controllers/leaderboardController');
const { protect } = require('../middleware/auth');

router.get('/', protect, leaderboard);

module.exports = router;
