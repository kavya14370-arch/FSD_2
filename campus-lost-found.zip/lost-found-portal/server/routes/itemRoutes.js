const router = require('express').Router();
const c = require('../controllers/itemController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(protect);
router.route('/').get(c.listItems).post(upload.single('image'), c.createItem);
router.get('/mine', c.myItems); // must stay above /:id
router.route('/:id').get(c.getItem).put(upload.single('image'), c.updateItem).delete(c.deleteItem);
router.get('/:id/matches', c.getMatches);

module.exports = router;
