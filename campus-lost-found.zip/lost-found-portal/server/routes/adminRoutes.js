const router = require('express').Router();
const c = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly);
router.get('/stats', c.stats);
router.get('/users', c.listUsers);
router.put('/users/:id/role', c.updateRole);
router.delete('/users/:id', c.deleteUser);
router.get('/claims', c.listClaims);
router.put('/claims/:id/review', c.reviewClaim);
router.put('/items/:id/mark-returned', c.markReturned);

module.exports = router;
