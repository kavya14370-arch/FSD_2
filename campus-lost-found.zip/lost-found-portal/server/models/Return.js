const mongoose = require('mongoose');

const returnSchema = new mongoose.Schema({
  itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true, unique: true },
  claimId: { type: mongoose.Schema.Types.ObjectId, ref: 'Claim' },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  finderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  returnedDate: { type: Date },
  confirmedByOwner: { type: Boolean, default: false },
  confirmedByFinder: { type: Boolean, default: false },
  pointsAwarded: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Return', returnSchema);
