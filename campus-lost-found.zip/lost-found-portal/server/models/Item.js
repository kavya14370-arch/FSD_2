const mongoose = require('mongoose');
const { CATEGORIES, LOCATIONS, ITEM_TYPES, ITEM_STATUS } = require('../config/constants');

const itemSchema = new mongoose.Schema({
  title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 100 },
  description: { type: String, required: [true, 'Description is required'], trim: true, maxlength: 1000 },
  category: { type: String, enum: CATEGORIES, required: true },
  image: { type: String }, // public path, e.g. /uploads/abc.jpg
  type: { type: String, enum: ITEM_TYPES, required: true },
  location: { type: String, enum: LOCATIONS, required: true },
  date: { type: Date, required: [true, 'Date is required'] },
  time: { type: String, match: [/^([01]\d|2[0-3]):[0-5]\d$/, 'Time must be HH:mm'] },
  color: { type: String, required: [true, 'Color is required'], trim: true, lowercase: true, maxlength: 30 },
  // Private detail only the poster and admins can see (e.g. a hidden mark). Used to verify claims.
  privateNote: { type: String, trim: true, maxlength: 300, select: false },
  status: { type: String, enum: ITEM_STATUS, default: 'OPEN' },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
});

itemSchema.index({ type: 1, status: 1, createdAt: -1 });
itemSchema.index({ category: 1, location: 1 });

module.exports = mongoose.model('Item', itemSchema);
