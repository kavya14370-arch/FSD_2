const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { asyncHandler, httpError } = require('../utils/helpers');

exports.protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.split(' ')[1] : null;
  if (!token) throw httpError(401, 'Please log in to continue');

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    throw httpError(401, 'Your session has expired. Log in again.');
  }
  const user = await User.findById(payload.id);
  if (!user) throw httpError(401, 'This account no longer exists');
  req.user = user;
  next();
});

exports.adminOnly = (req, res, next) =>
  req.user?.role === 'admin' ? next() : next(httpError(403, 'Admin access required'));
