// npm run seed  - creates the admin account plus a small demo data set (safe to run more than once)
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Item = require('./models/Item');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);

  const upsert = async (data) => (await User.findOne({ email: data.email })) || User.create(data);
  await upsert({ name: 'Campus Admin', email: process.env.ADMIN_EMAIL || 'admin@campus.edu', password: process.env.ADMIN_PASSWORD || 'Admin@12345', role: 'admin' });
  const asha = await upsert({ name: 'Asha Rao', email: 'asha@campus.edu', password: 'student123', rollNo: '21CS101', department: 'CSE', year: 3 });
  const ravi = await upsert({ name: 'Ravi Kumar', email: 'ravi@campus.edu', password: 'student123', rollNo: '21EC045', department: 'ECE', year: 2 });

  if (!(await Item.countDocuments())) {
    const today = new Date();
    const daysAgo = (n) => new Date(today - n * 86400000);
    await Item.create([
      { title: 'Black Casio calculator', description: 'Scientific calculator with a cracked corner, left on a desk after the exam', category: 'Electronics', type: 'LOST', location: 'Block A', date: daysAgo(2), time: '11:30', color: 'black', postedBy: asha._id },
      { title: 'Calculator found in classroom', description: 'Black scientific calculator with cracked corner, found on a desk', category: 'Electronics', type: 'FOUND', location: 'Block A', date: daysAgo(1), time: '14:10', color: 'black', privateNote: 'Initials AR scratched on the back', postedBy: ravi._id },
      { title: 'Blue water bottle', description: 'Steel bottle with a sticker of a mountain', category: 'Accessories', type: 'FOUND', location: 'Canteen', date: daysAgo(3), time: '13:00', color: 'blue', postedBy: ravi._id },
    ]);
  }
  console.log('Seeded. Admin login:', process.env.ADMIN_EMAIL || 'admin@campus.edu');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
