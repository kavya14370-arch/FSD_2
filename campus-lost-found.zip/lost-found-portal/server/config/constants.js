module.exports = {
  CATEGORIES: ['Electronics', 'Books & Notes', 'ID & Cards', 'Wallet & Money', 'Keys', 'Bags', 'Clothing', 'Accessories', 'Stationery', 'Other'],
  LOCATIONS: ['Block A', 'Block B', 'Block C', 'Library', 'Canteen', 'Auditorium', 'Sports Ground', 'Hostel', 'Parking', 'Labs', 'Other'],
  ITEM_TYPES: ['LOST', 'FOUND'],
  // OPEN -> PENDING_CLAIM (a claim awaits review) -> APPROVED (admin approved, handover pending) -> RETURNED
  ITEM_STATUS: ['OPEN', 'PENDING_CLAIM', 'APPROVED', 'RETURNED'],
  POINTS_PER_RETURN: 10,
  MATCH_THRESHOLD: 40, // minimum score (%) for a suggestion to be shown
};
