const User = require('../models/User');
const Item = require('../models/Item');
const Claim = require('../models/Claim');
const Return = require('../models/Return');
const { finalizeReturn } = require('../utils/returns');
const { asyncHandler, httpError, escapeRegex, removeImage } = require('../utils/helpers');

// GET /api/admin/stats
exports.stats = asyncHandler(async (req, res) => {
  const [users, totalItems, lost, found, returned, pendingClaims, topLostLocations, byCategory] = await Promise.all([
    User.countDocuments(),
    Item.countDocuments(),
    Item.countDocuments({ type: 'LOST' }),
    Item.countDocuments({ type: 'FOUND' }),
    Item.countDocuments({ status: 'RETURNED' }),
    Claim.countDocuments({ status: 'PENDING' }),
    Item.aggregate([{ $match: { type: 'LOST' } }, { $group: { _id: '$location', count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 6 }]),
    Item.aggregate([{ $group: { _id: '$category', count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
  ]);
  res.json({
    totals: { users, items: totalItems, lost, found, returned, pendingClaims },
    recoveryRate: totalItems ? Math.round((returned / totalItems) * 100) : 0,
    topLostLocations: topLostLocations.map((r) => ({ label: r._id, count: r.count })),
    byCategory: byCategory.map((r) => ({ label: r._id, count: r.count })),
  });
});

// GET /api/admin/users?q=
exports.listUsers = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.q) {
    const rx = new RegExp(escapeRegex(String(req.query.q).slice(0, 60)), 'i');
    filter.$or = [{ name: rx }, { email: rx }, { rollNo: rx }];
  }
  res.json({ users: await User.find(filter).sort({ createdAt: -1 }).limit(200) });
});

// PUT /api/admin/users/:id/role  { role }
exports.updateRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  if (!['student', 'faculty', 'admin'].includes(role)) throw httpError(400, 'Invalid role');
  if (String(req.params.id) === String(req.user._id)) throw httpError(400, 'You cannot change your own role');
  const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true });
  if (!user) throw httpError(404, 'User not found');
  res.json({ user });
});

// DELETE /api/admin/users/:id - removes the user and everything they posted
exports.deleteUser = asyncHandler(async (req, res) => {
  if (String(req.params.id) === String(req.user._id)) throw httpError(400, 'You cannot delete your own account');
  const user = await User.findById(req.params.id);
  if (!user) throw httpError(404, 'User not found');

  const items = await Item.find({ postedBy: user._id });
  const ids = items.map((i) => i._id);
  items.forEach((i) => removeImage(i.image));
  await Promise.all([
    Claim.deleteMany({ $or: [{ claimantId: user._id }, { itemId: { $in: ids } }] }),
    Return.deleteMany({ $or: [{ itemId: { $in: ids } }, { ownerId: user._id }, { finderId: user._id }] }),
    Item.deleteMany({ postedBy: user._id }),
  ]);
  await user.deleteOne();
  res.json({ message: 'User and their posts deleted' });
});

// GET /api/admin/claims?status=PENDING|APPROVED|REJECTED|ALL
exports.listClaims = asyncHandler(async (req, res) => {
  const status = String(req.query.status || 'PENDING').toUpperCase();
  const filter = status === 'ALL' ? {} : { status };
  const claims = await Claim.find(filter)
    .sort({ itemId: 1, createdAt: 1 })
    .populate('claimantId', 'name email rollNo department year')
    .populate({ path: 'itemId', select: '+privateNote title description type category location color image status date postedBy', populate: { path: 'postedBy', select: 'name email rollNo department' } });
  res.json({ claims: claims.filter((c) => c.itemId) });
});

// PUT /api/admin/claims/:id/review  { status: 'APPROVED' | 'REJECTED', adminComment }
exports.reviewClaim = asyncHandler(async (req, res) => {
  const { status, adminComment } = req.body;
  if (!['APPROVED', 'REJECTED'].includes(status)) throw httpError(400, 'Status must be APPROVED or REJECTED');
  if (status === 'REJECTED' && !adminComment?.trim()) throw httpError(400, 'Add a comment explaining the rejection');

  const claim = await Claim.findById(req.params.id);
  if (!claim) throw httpError(404, 'Claim not found');
  if (claim.status !== 'PENDING') throw httpError(400, 'This claim has already been reviewed');
  const item = await Item.findById(claim.itemId);
  if (!item) throw httpError(404, 'The item for this claim no longer exists');
  if (['APPROVED', 'RETURNED'].includes(item.status)) throw httpError(400, 'Another claim was already approved for this item');

  claim.status = status;
  claim.adminComment = adminComment;
  await claim.save();

  if (status === 'APPROVED') {
    // every competing claim is closed
    await Claim.updateMany(
      { itemId: item._id, _id: { $ne: claim._id }, status: 'PENDING' },
      { status: 'REJECTED', adminComment: 'Another claim for this item was approved.' }
    );
    item.status = 'APPROVED';
    await item.save();
    // FOUND post: poster is the finder, claimant is the owner. LOST post: the reverse.
    const [ownerId, finderId] = item.type === 'FOUND' ? [claim.claimantId, item.postedBy] : [item.postedBy, claim.claimantId];
    await Return.create({ itemId: item._id, claimId: claim._id, ownerId, finderId });
  } else {
    const stillPending = await Claim.exists({ itemId: item._id, status: 'PENDING' });
    if (!stillPending) {
      item.status = 'OPEN';
      await item.save();
    }
  }
  res.json({ claim });
});

// PUT /api/admin/items/:id/mark-returned - manual override when both sides handed over offline
exports.markReturned = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) throw httpError(404, 'Item not found');
  const ret = await Return.findOne({ itemId: item._id });
  if (ret) {
    ret.confirmedByOwner = true;
    ret.confirmedByFinder = true;
    await finalizeReturn(ret); // awards finder points
  } else {
    item.status = 'RETURNED'; // no approved claim on record, so nobody earns points
    await item.save();
  }
  res.json({ message: 'Item marked as returned' });
});
