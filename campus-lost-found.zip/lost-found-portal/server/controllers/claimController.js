const Claim = require('../models/Claim');
const Item = require('../models/Item');
const { asyncHandler, httpError } = require('../utils/helpers');

// POST /api/claims  { itemId, proof, reason }
// FOUND item: the claimant says "this is mine".  LOST item: the claimant says "I found this".
exports.createClaim = asyncHandler(async (req, res) => {
  const { itemId, proof, reason } = req.body;
  const item = await Item.findById(itemId);
  if (!item) throw httpError(404, 'Item not found');
  if (String(item.postedBy) === String(req.user._id)) throw httpError(400, 'You cannot claim your own post');
  if (!['OPEN', 'PENDING_CLAIM'].includes(item.status)) throw httpError(400, 'This item is no longer open for claims');

  const existing = await Claim.findOne({ itemId, claimantId: req.user._id, status: 'PENDING' });
  if (existing) throw httpError(409, 'You already have a pending claim on this item');

  const claim = await Claim.create({ itemId, claimantId: req.user._id, proof, reason });
  item.status = 'PENDING_CLAIM';
  await item.save();
  res.status(201).json({ claim });
});

// GET /api/claims/mine
exports.myClaims = asyncHandler(async (req, res) => {
  const claims = await Claim.find({ claimantId: req.user._id }).sort({ createdAt: -1 }).populate('itemId', 'title type image location status');
  res.json({ claims });
});

// DELETE /api/claims/:id  (withdraw your own pending claim)
exports.withdrawClaim = asyncHandler(async (req, res) => {
  const claim = await Claim.findById(req.params.id);
  if (!claim || String(claim.claimantId) !== String(req.user._id)) throw httpError(404, 'Claim not found');
  if (claim.status !== 'PENDING') throw httpError(400, 'Only pending claims can be withdrawn');
  await claim.deleteOne();

  const stillPending = await Claim.exists({ itemId: claim.itemId, status: 'PENDING' });
  if (!stillPending) await Item.updateOne({ _id: claim.itemId, status: 'PENDING_CLAIM' }, { status: 'OPEN' });
  res.json({ message: 'Claim withdrawn' });
});
