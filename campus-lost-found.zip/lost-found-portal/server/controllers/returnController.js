const Return = require('../models/Return');
const { finalizeReturn } = require('../utils/returns');
const { asyncHandler, httpError } = require('../utils/helpers');

// GET /api/returns/mine  - handovers where I am the owner or the finder
exports.myReturns = asyncHandler(async (req, res) => {
  const returns = await Return.find({ $or: [{ ownerId: req.user._id }, { finderId: req.user._id }] })
    .sort({ createdAt: -1 })
    .populate('itemId', 'title type image location')
    .populate('ownerId', 'name department')
    .populate('finderId', 'name department');
  res.json({ returns });
});

// PUT /api/returns/:id/confirm - each side confirms the handover; when both have, the finder earns points
exports.confirmReturn = asyncHandler(async (req, res) => {
  const ret = await Return.findById(req.params.id);
  if (!ret) throw httpError(404, 'Handover not found');

  const me = String(req.user._id);
  if (me === String(ret.ownerId)) ret.confirmedByOwner = true;
  else if (me === String(ret.finderId)) ret.confirmedByFinder = true;
  else throw httpError(403, 'You are not part of this handover');

  await ret.save();
  if (ret.confirmedByOwner && ret.confirmedByFinder) await finalizeReturn(ret);
  res.json({ return: ret, completed: ret.pointsAwarded });
});
