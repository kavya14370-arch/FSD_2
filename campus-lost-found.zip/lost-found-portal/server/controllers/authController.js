const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { asyncHandler, httpError } = require('../utils/helpers');

const signToken = (user) =>
  jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const publicUser = (u) => ({
  _id: u._id, name: u.name, email: u.email, rollNo: u.rollNo, department: u.department,
  year: u.year, role: u.role, points: u.points, createdAt: u.createdAt,
});

// POST /api/auth/register  (self-registration is only ever student or faculty; admins come from the seed script)
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, rollNo, department, year, role } = req.body;
  if (!name || !email || !password) throw httpError(400, 'Name, email and password are required');
  const accountRole = role === 'faculty' ? 'faculty' : 'student';
  if (accountRole === 'student' && !rollNo) throw httpError(400, 'Roll number is required for students');

  const user = await User.create({
    name, email, password, department,
    rollNo: rollNo || undefined,
    year: year ? Number(year) : undefined,
    role: accountRole,
  });
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw httpError(400, 'Enter your email and password');
  const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(password))) throw httpError(401, 'Email or password is incorrect');
  res.json({ token: signToken(user), user: publicUser(user) });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => res.json({ user: publicUser(req.user) }));
