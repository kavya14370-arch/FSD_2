const Item = require('../models/Item');
const Claim = require('../models/Claim');
const Return = require('../models/Return');
const { findMatches } = require('../utils/matching');
const { asyncHandler, httpError, escapeRegex, removeImage } = require('../utils/helpers');

const FIELDS = ['title', 'description', 'category', 'type', 'location', 'date', 'time', 'color', 'privateNote'];
const pick = (body) => Object.fromEntries(FIELDS.filter((k) => body[k] !== undefined && body[k] !== '').map((k) => [k, body[k]]));

const isOwner = (item, user) => String(item.postedBy._id || item.postedBy) === String(user._id);

function assertNotFuture(date) {
  if (date && new Date(date) > new Date(Date.now() + 24 * 3600 * 1000)) throw httpError(400, 'Date cannot be in the future');
}

// POST /api/items  (multipart/form-data, optional "image")
exports.createItem = asyncHandler(async (req, res) => {
  try {
    const data = pick(req.body);
    assertNotFuture(data.date);
    if (req.file) data.image = `/uploads/${req.file.filename}`;
    const item = await Item.create({ ...data, postedBy: req.user._id });
    const matches = await findMatches(item);
    res.status(201).json({ item, matches });
  } catch (err) {
    if (req.file) removeImage(`/uploads/${req.file.filename}`);
    throw err;
  }
});

// GET /api/items?type=&category=&location=&status=&q=&page=&limit=
exports.listItems = asyncHandler(async (req, res) => {
  const { type, category, location, status, q } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit, 10) || 12, 50);

  const filter = {};
  if (type) filter.type = String(type).toUpperCase();
  if (category) filter.category = String(category);
  if (location) filter.location = String(location);
  // By default hide items that are already approved/returned. Use status=ALL to see everything.
  if (!status) filter.status = { $in: ['OPEN', 'PENDING_CLAIM'] };
  else if (status !== 'ALL') filter.status = String(status);
  if (q) {
    const rx = new RegExp(escapeRegex(String(q).slice(0, 60)), 'i');
    filter.$or = [{ title: rx }, { description: rx }, { color: rx }];
  }

  const [items, total] = await Promise.all([
    Item.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate('postedBy', 'name department'),
    Item.countDocuments(filter),
  ]);
  res.json({ items, total, page, pages: Math.max(Math.ceil(total / limit), 1) });
});

// GET /api/items/mine
exports.myItems = asyncHandler(async (req, res) => {
  const items = await Item.find({ postedBy: req.user._id }).sort({ createdAt: -1 });
  res.json({ items });
});

// GET /api/items/:id
exports.getItem = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id).select('+privateNote').populate('postedBy', 'name department year role');
  if (!item) throw httpError(404, 'Item not found');

  const obj = item.toObject();
  const canSeePrivate = isOwner(item, req.user) || req.user.role === 'admin';
  if (!canSeePrivate) delete obj.privateNote;

  const myClaim = await Claim.findOne({ itemId: item._id, claimantId: req.user._id }).sort({ createdAt: -1 });
  res.json({ item: obj, myClaim, isOwner: isOwner(item, req.user) });
});

// GET /api/items/:id/matches  (poster or admin)
exports.getMatches = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) throw httpError(404, 'Item not found');
  if (!isOwner(item, req.user) && req.user.role !== 'admin') throw httpError(403, 'Only the poster can see matches');
  res.json({ matches: await findMatches(item, { limit: 8 }) });
});

// PUT /api/items/:id  (poster, only while OPEN)
exports.updateItem = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) throw httpError(404, 'Item not found');
  if (!isOwner(item, req.user)) throw httpError(403, 'You can only edit your own posts');
  if (item.status !== 'OPEN') throw httpError(400, 'This post can no longer be edited because a claim is in progress');

  const data = pick(req.body);
  delete data.type; // switching LOST/FOUND would break existing claims
  assertNotFuture(data.date);
  Object.assign(item, data);
  if (req.file) {
    removeImage(item.image);
    item.image = `/uploads/${req.file.filename}`;
  }
  await item.save();
  res.json({ item, matches: await findMatches(item) });
});

// DELETE /api/items/:id  (poster before approval, or admin any time)
exports.deleteItem = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) throw httpError(404, 'Item not found');
  const admin = req.user.role === 'admin';
  if (!admin && !isOwner(item, req.user)) throw httpError(403, 'You can only delete your own posts');
  if (!admin && ['APPROVED', 'RETURNED'].includes(item.status)) throw httpError(400, 'Items with an approved claim cannot be deleted');

  await Promise.all([Claim.deleteMany({ itemId: item._id }), Return.deleteMany({ itemId: item._id })]);
  removeImage(item.image);
  await item.deleteOne();
  res.json({ message: 'Item deleted' });
});
