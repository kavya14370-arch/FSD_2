const Return = require('../models/Return');
const { asyncHandler } = require('../utils/helpers');

// GET /api/leaderboard - top finders by points
exports.leaderboard = asyncHandler(async (req, res) => {
  const rows = await Return.aggregate([
    { $match: { pointsAwarded: true } },
    { $group: { _id: '$finderId', returns: { $sum: 1 } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
    { $unwind: '$user' },
    { $project: { _id: 1, returns: 1, name: '$user.name', department: '$user.department', year: '$user.year', points: '$user.points' } },
    { $sort: { points: -1, returns: -1 } },
    { $limit: 20 },
  ]);
  res.json({ leaders: rows });
});
