// Keep in sync with server/config/constants.js
export const CATEGORIES = ['Electronics', 'Books & Notes', 'ID & Cards', 'Wallet & Money', 'Keys', 'Bags', 'Clothing', 'Accessories', 'Stationery', 'Other'];
export const LOCATIONS = ['Block A', 'Block B', 'Block C', 'Library', 'Canteen', 'Auditorium', 'Sports Ground', 'Hostel', 'Parking', 'Labs', 'Other'];

export const STATUS_LABEL = {
  OPEN: 'Open',
  PENDING_CLAIM: 'Claim under review',
  APPROVED: 'Claim approved',
  RETURNED: 'Returned',
  PENDING: 'Under review',
  REJECTED: 'Rejected',
};

export const MATCH_LABEL = { category: 'Category', location: 'Location', date: 'Date', color: 'Color', keywords: 'Description' };
export const MATCH_MAX = { category: 25, location: 25, date: 20, color: 15, keywords: 15 };
