import { Link } from 'react-router-dom';
import { MATCH_LABEL, MATCH_MAX } from '../constants';
import { imgUrl } from '../api';

export default function MatchList({ matches, heading = 'Possible matches' }) {
  if (!matches) return null;
  return (
    <section className="panel">
      <h2>{heading}</h2>
      {matches.length === 0 ? (
        <p className="muted">No close matches yet. We re-check whenever someone posts a new item, so look again later.</p>
      ) : (
        <ul className="matches">
          {matches.map(({ item, score, breakdown }) => (
            <li key={item._id}>
              <Link to={`/items/${item._id}`} className="match-main">
                <div className="score" style={{ '--p': score }} aria-label={`${score}% match`}><span>{score}%</span></div>
                {item.image && <img src={imgUrl(item.image)} alt="" />}
                <div>
                  <strong>{item.title}</strong>
                  <div className="muted">{item.type === 'LOST' ? 'Lost' : 'Found'} at {item.location}</div>
                </div>
              </Link>
              <div className="bars">
                {Object.keys(MATCH_LABEL).map((k) => (
                  <div key={k} className="bar-row" title={`${breakdown[k]} of ${MATCH_MAX[k]} points`}>
                    <span>{MATCH_LABEL[k]}</span>
                    <div className="bar"><i style={{ width: `${(breakdown[k] / MATCH_MAX[k]) * 100}%` }} /></div>
                  </div>
                ))}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
