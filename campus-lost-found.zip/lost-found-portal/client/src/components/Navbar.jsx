import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="nav">
      <div className="nav-inner">
        <Link to="/" className="brand"><span className="hole" aria-hidden="true" />Campus Lost &amp; Found</Link>
        {user ? (
          <nav aria-label="Main">
            <NavLink to="/" end>Browse</NavLink>
            <NavLink to="/report">Report an item</NavLink>
            <NavLink to="/dashboard">My activity</NavLink>
            <NavLink to="/leaderboard">Leaderboard</NavLink>
            {user.role === 'admin' && <NavLink to="/admin">Admin</NavLink>}
            <span className="nav-user">{user.name.split(" ")[0]}, {user.points} pts</span>
            <button className="btn ghost small" onClick={() => { logout(); navigate('/login'); }}>Log out</button>
          </nav>
        ) : (
          <nav aria-label="Main">
            <NavLink to="/login">Log in</NavLink>
            <NavLink to="/register">Create account</NavLink>
          </nav>
        )}
      </div>
    </header>
  );
}
