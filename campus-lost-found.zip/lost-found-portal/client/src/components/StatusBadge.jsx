import { STATUS_LABEL } from '../constants';

export default function StatusBadge({ status }) {
  return <span className={`badge st-${status}`}>{STATUS_LABEL[status] || status}</span>;
}
