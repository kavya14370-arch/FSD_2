import { Link } from 'react-router-dom';
import { imgUrl, fmtDate } from '../api';
import StatusBadge from './StatusBadge';

// An item shown as a luggage tag: punched hole, coloured edge for lost (coral) or found (teal)
export default function ItemCard({ item }) {
  const img = imgUrl(item.image);
  return (
    <Link to={`/items/${item._id}`} className={`tag ${item.type.toLowerCase()}`}>
      <div className="tag-head">
        <span className="hole" aria-hidden="true" />
        <strong className="tag-type">{item.type === 'LOST' ? 'Lost' : 'Found'}</strong>
        {item.status !== 'OPEN' && <StatusBadge status={item.status} />}
      </div>
      {img ? <img src={img} alt={item.title} loading="lazy" /> : <div className="tag-noimg">No photo</div>}
      <h3>{item.title}</h3>
      <p className="muted clamp">{item.description}</p>
      <dl className="facts">
        <div><dt>Where</dt><dd>{item.location}</dd></div>
        <div><dt>When</dt><dd>{fmtDate(item.date)}{item.time ? `, ${item.time}` : ''}</dd></div>
        <div><dt>Category</dt><dd>{item.category}</dd></div>
      </dl>
    </Link>
  );
}
