import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { errMsg } from '../api';
import { CATEGORIES, LOCATIONS } from '../constants';

const today = () => new Date().toISOString().slice(0, 10);
const nowTime = () => new Date().toTimeString().slice(0, 5);

export default function ReportItem() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ type: 'LOST', title: '', category: CATEGORIES[0], description: '', color: '', location: LOCATIONS[0], date: today(), time: nowTime(), privateNote: '' });
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const found = form.type === 'FOUND';

  const pickFile = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) return setError('Image must be 5 MB or smaller');
    setError('');
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => v && fd.append(k, v));
      if (file) fd.append('image', file);
      const { data } = await api.post('/items', fd);
      navigate(`/items/${data.item._id}`, { state: { posted: true } });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="narrow">
      <h1>Report an item</h1>
      <form onSubmit={submit} className="stack panel">
        {error && <div className="alert error" role="alert">{error}</div>}
        <div className="seg big" role="group" aria-label="What happened">
          <button type="button" className={!found ? 'on lost' : ''} onClick={() => setForm({ ...form, type: 'LOST' })}>I lost something</button>
          <button type="button" className={found ? 'on found' : ''} onClick={() => setForm({ ...form, type: 'FOUND' })}>I found something</button>
        </div>
        <label>Title<input required maxLength={100} placeholder={found ? 'Blue umbrella near the gate' : 'Black wallet with a college ID'} value={form.title} onChange={set('title')} /></label>
        <div className="row">
          <label>Category<select value={form.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label>Color<input required maxLength={30} placeholder="e.g. black, dark blue" value={form.color} onChange={set('color')} /></label>
        </div>
        <label>Description<textarea required rows={4} maxLength={1000} placeholder="Brand, size, stickers, contents. Good detail improves matching." value={form.description} onChange={set('description')} /></label>
        <div className="row">
          <label>Location<select value={form.location} onChange={set('location')}>{LOCATIONS.map((l) => <option key={l}>{l}</option>)}</select></label>
          <label>Date<input type="date" required max={today()} value={form.date} onChange={set('date')} /></label>
          <label>Time<input type="time" value={form.time} onChange={set('time')} /></label>
        </div>
        <label>Photo (optional)
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={pickFile} />
        </label>
        {preview && <img src={preview} alt="Selected item preview" className="preview" />}
        {found && (
          <label>Private identifying detail (optional)
            <input maxLength={300} placeholder="Something only the real owner would know, such as initials or the wallpaper" value={form.privateNote} onChange={set('privateNote')} />
            <small className="muted">Only you and the admins can see this. Admins compare it with claim proofs.</small>
          </label>
        )}
        <button className="btn" disabled={busy}>{busy ? 'Posting...' : 'Post item'}</button>
      </form>
    </div>
  );
}
