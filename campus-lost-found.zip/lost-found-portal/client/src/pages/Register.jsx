import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'student', rollNo: '', department: '', year: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const student = form.role === 'student';

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await register(form);
      navigate('/', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <h1>Create your account</h1>
      <form onSubmit={submit} className="stack">
        {error && <div className="alert error" role="alert">{error}</div>}
        <div className="seg" role="group" aria-label="I am a">
          {['student', 'faculty'].map((r) => (
            <button type="button" key={r} className={form.role === r ? 'on' : ''} onClick={() => setForm({ ...form, role: r })}>
              {r === 'student' ? 'Student' : 'Faculty'}
            </button>
          ))}
        </div>
        <label>Full name<input required value={form.name} onChange={set('name')} /></label>
        <label>Email<input type="email" required autoComplete="email" value={form.email} onChange={set('email')} /></label>
        <label>Password<input type="password" required minLength={6} autoComplete="new-password" value={form.password} onChange={set('password')} /><small className="muted">At least 6 characters</small></label>
        <div className="row">
          {student && <label>Roll number<input required value={form.rollNo} onChange={set('rollNo')} /></label>}
          <label>Department<input value={form.department} onChange={set('department')} /></label>
          {student && <label>Year<select value={form.year} onChange={set('year')}><option value="">Select</option>{[1, 2, 3, 4, 5].map((y) => <option key={y} value={y}>{y}</option>)}</select></label>}
        </div>
        <button className="btn" disabled={busy}>{busy ? 'Creating account...' : 'Create account'}</button>
      </form>
      <p className="muted">Already registered? <Link to="/login">Log in</Link></p>
    </div>
  );
}
