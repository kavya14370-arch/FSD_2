import { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import api, { errMsg, imgUrl, fmtDate } from '../api';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';
import MatchList from '../components/MatchList';

export default function ItemDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { state } = useLocation();
  const [data, setData] = useState(null);
  const [matches, setMatches] = useState(null);
  const [error, setError] = useState('');
  const [claim, setClaim] = useState({ proof: '', reason: '' });
  const [busy, setBusy] = useState(false);

  const load = () =>
    api.get(`/items/${id}`)
      .then(async (r) => {
        setData(r.data);
        if (r.data.isOwner) setMatches((await api.get(`/items/${id}/matches`)).data.matches);
      })
      .catch((e) => setError(errMsg(e)));

  useEffect(() => { setData(null); setMatches(null); load(); }, [id]); // eslint-disable-line

  if (error && !data) return <div className="alert error" role="alert">{error}</div>;
  if (!data) return <p className="muted">Loading item...</p>;

  const { item, myClaim, isOwner } = data;
  const lost = item.type === 'LOST';
  const open = ['OPEN', 'PENDING_CLAIM'].includes(item.status);
  const canClaim = !isOwner && open && myClaim?.status !== 'PENDING';

  const submitClaim = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api.post('/claims', { itemId: item._id, ...claim });
      setClaim({ proof: '', reason: '' });
      await load();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!window.confirm('Delete this post? Any claims on it will be removed too.')) return;
    try {
      await api.delete(`/items/${item._id}`);
      navigate('/dashboard');
    } catch (err) {
      setError(errMsg(err));
    }
  };

  return (
    <div className="detail">
      {state?.posted && <div className="alert ok">Posted. We checked for matches and list them below.</div>}
      {error && <div className="alert error" role="alert">{error}</div>}

      <section className={`panel tag-lg ${item.type.toLowerCase()}`}>
        <div className="tag-head">
          <span className="hole" aria-hidden="true" />
          <strong className="tag-type">{lost ? 'Lost' : 'Found'}</strong>
          <StatusBadge status={item.status} />
        </div>
        <div className="detail-body">
          {item.image && <img src={imgUrl(item.image)} alt={item.title} className="detail-img" />}
          <div>
            <h1>{item.title}</h1>
            <p>{item.description}</p>
            <dl className="facts wide">
              <div><dt>Category</dt><dd>{item.category}</dd></div>
              <div><dt>Color</dt><dd>{item.color}</dd></div>
              <div><dt>Location</dt><dd>{item.location}</dd></div>
              <div><dt>{lost ? 'Lost on' : 'Found on'}</dt><dd>{fmtDate(item.date)}{item.time ? `, ${item.time}` : ''}</dd></div>
              <div><dt>Posted by</dt><dd>{item.postedBy?.name}{item.postedBy?.department ? `, ${item.postedBy.department}` : ''}</dd></div>
            </dl>
            {item.privateNote && <p className="alert info"><strong>Your private detail:</strong> {item.privateNote}</p>}
            {(isOwner || user.role === 'admin') && (
              <button className="btn ghost danger small" onClick={remove}>Delete post</button>
            )}
          </div>
        </div>
      </section>

      {myClaim && (
        <section className="panel">
          <h2>Your claim</h2>
          <p><StatusBadge status={myClaim.status} /></p>
          <p className="muted">Submitted proof: {myClaim.proof}</p>
          {myClaim.adminComment && <p className="alert info"><strong>Admin note:</strong> {myClaim.adminComment}</p>}
          {myClaim.status === 'APPROVED' && <p>Approved. Arrange the handover, then confirm it under <strong>My activity</strong>.</p>}
        </section>
      )}

      {canClaim && (
        <section className="panel">
          <h2>{lost ? 'I found this item' : 'This is my item'}</h2>
          <p className="muted">
            {lost
              ? 'Tell the owner and admin where you found it and describe something that proves it is in your hands.'
              : 'Describe something only the owner would know: a serial number, a scratch, what is inside. An admin will compare your answer with the finder’s details.'}
          </p>
          <form onSubmit={submitClaim} className="stack">
            <label>Proof<textarea required rows={3} minLength={10} maxLength={1000} placeholder={lost ? 'Where you found it and an identifying detail' : 'Serial number, unique marks or contents'} value={claim.proof} onChange={(e) => setClaim({ ...claim, proof: e.target.value })} /></label>
            <label>{lost ? 'Where is the item now?' : 'How did you lose it?'}<textarea rows={2} maxLength={500} value={claim.reason} onChange={(e) => setClaim({ ...claim, reason: e.target.value })} /></label>
            <button className="btn" disabled={busy}>{busy ? 'Sending...' : 'Send claim request'}</button>
          </form>
        </section>
      )}

      {isOwner && <MatchList matches={matches} heading={lost ? 'Found items that may be yours' : 'Lost reports that may belong to this item'} />}
    </div>
  );
}
