import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmtDate } from '../api';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';
import ItemCard from '../components/ItemCard';

export default function Dashboard() {
  const { user, refresh } = useAuth();
  const [tab, setTab] = useState('posts');
  const [items, setItems] = useState([]);
  const [claims, setClaims] = useState([]);
  const [returns, setReturns] = useState([]);
  const [error, setError] = useState('');

  const load = () =>
    Promise.all([api.get('/items/mine'), api.get('/claims/mine'), api.get('/returns/mine')])
      .then(([i, c, r]) => { setItems(i.data.items); setClaims(c.data.claims); setReturns(r.data.returns); })
      .catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const confirm = async (id) => {
    try {
      const { data } = await api.put(`/returns/${id}/confirm`);
      await load();
      if (data.completed) refresh(); // the finder's points just changed
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const withdraw = async (id) => {
    try { await api.delete(`/claims/${id}`); load(); } catch (e) { setError(errMsg(e)); }
  };

  const pendingHandovers = returns.filter((r) => !r.pointsAwarded).length;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>My activity</h1>
          <p className="muted">You have {user.points} finder points.</p>
        </div>
      </div>
      {error && <div className="alert error" role="alert">{error}</div>}
      <div className="seg" role="tablist">
        <button className={tab === 'posts' ? 'on' : ''} onClick={() => setTab('posts')}>My posts ({items.length})</button>
        <button className={tab === 'claims' ? 'on' : ''} onClick={() => setTab('claims')}>My claims ({claims.length})</button>
        <button className={tab === 'returns' ? 'on' : ''} onClick={() => setTab('returns')}>Handovers{pendingHandovers ? ` (${pendingHandovers} to confirm)` : ''}</button>
      </div>

      {tab === 'posts' && (items.length === 0
        ? <div className="empty"><p>You have not reported anything yet.</p><Link className="btn" to="/report">Report an item</Link></div>
        : <div className="grid">{items.map((i) => <ItemCard key={i._id} item={i} />)}</div>)}

      {tab === 'claims' && (claims.length === 0
        ? <div className="empty"><p>You have not sent any claims. Open an item on the Browse page to claim it.</p></div>
        : <ul className="rows">{claims.map((c) => (
          <li key={c._id}>
            <div>
              <Link to={`/items/${c.itemId?._id}`}><strong>{c.itemId?.title || 'Deleted item'}</strong></Link>
              <div className="muted">Sent {fmtDate(c.createdAt)}</div>
              {c.adminComment && <div className="muted">Admin note: {c.adminComment}</div>}
            </div>
            <div className="actions">
              <StatusBadge status={c.status} />
              {c.status === 'PENDING' && <button className="btn ghost small" onClick={() => withdraw(c._id)}>Withdraw</button>}
            </div>
          </li>))}</ul>)}

      {tab === 'returns' && (returns.length === 0
        ? <div className="empty"><p>No approved claims yet. When an admin approves a claim, the handover shows up here.</p></div>
        : <ul className="rows">{returns.map((r) => {
          const iAmOwner = String(r.ownerId?._id) === String(user._id);
          const mine = iAmOwner ? r.confirmedByOwner : r.confirmedByFinder;
          const other = iAmOwner ? r.finderId : r.ownerId;
          return (
            <li key={r._id}>
              <div>
                <Link to={`/items/${r.itemId?._id}`}><strong>{r.itemId?.title}</strong></Link>
                <div className="muted">You are the {iAmOwner ? 'owner' : 'finder'}. {iAmOwner ? 'Finder' : 'Owner'}: {other?.name}{other?.department ? `, ${other.department}` : ''}</div>
                <div className="muted">Owner {r.confirmedByOwner ? 'has confirmed' : 'has not confirmed'}. Finder {r.confirmedByFinder ? 'has confirmed' : 'has not confirmed'}.</div>
              </div>
              <div className="actions">
                {r.pointsAwarded ? <span className="badge st-RETURNED">Completed</span>
                  : mine ? <span className="muted">Waiting for the other person</span>
                  : <button className="btn small" onClick={() => confirm(r._id)}>Confirm handover</button>}
              </div>
            </li>);
        })}</ul>)}
    </>
  );
}
