import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import ItemCard from '../components/ItemCard';
import { CATEGORIES, LOCATIONS } from '../constants';

export default function Browse() {
  const [filters, setFilters] = useState({ type: '', category: '', location: '', q: '' });
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ items: [], pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const t = setTimeout(() => {
      setLoading(true);
      api.get('/items', { params: { ...filters, page } })
        .then((r) => { setData(r.data); setError(''); })
        .catch((e) => setError(errMsg(e)))
        .finally(() => setLoading(false));
    }, 250); // debounce the search box
    return () => clearTimeout(t);
  }, [filters, page]);

  const set = (k, v) => { setPage(1); setFilters((f) => ({ ...f, [k]: v })); };

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Lost and found on campus</h1>
          <p className="muted">Lost something? Search first, then report it. Found something? Post it so the owner can find it.</p>
        </div>
        <Link to="/report" className="btn">Report an item</Link>
      </div>

      <div className="filters">
        <div className="seg" role="group" aria-label="Item type">
          {[['', 'All'], ['LOST', 'Lost'], ['FOUND', 'Found']].map(([v, label]) => (
            <button key={v} className={filters.type === v ? 'on' : ''} onClick={() => set('type', v)}>{label}</button>
          ))}
        </div>
        <input type="search" placeholder="Search title, description or color" value={filters.q} onChange={(e) => set('q', e.target.value)} aria-label="Search items" />
        <select value={filters.category} onChange={(e) => set('category', e.target.value)} aria-label="Category">
          <option value="">All categories</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select value={filters.location} onChange={(e) => set('location', e.target.value)} aria-label="Location">
          <option value="">All locations</option>{LOCATIONS.map((l) => <option key={l}>{l}</option>)}
        </select>
      </div>

      {error && <div className="alert error" role="alert">{error}</div>}
      {loading ? <p className="muted">Loading items...</p> : data.items.length === 0 ? (
        <div className="empty"><p>No items match these filters.</p><Link to="/report" className="btn">Report what you lost or found</Link></div>
      ) : (
        <div className="grid">{data.items.map((i) => <ItemCard key={i._id} item={i} />)}</div>
      )}

      {data.pages > 1 && (
        <div className="pager">
          <button className="btn ghost small" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span className="muted">Page {page} of {data.pages}</span>
          <button className="btn ghost small" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </>
  );
}
