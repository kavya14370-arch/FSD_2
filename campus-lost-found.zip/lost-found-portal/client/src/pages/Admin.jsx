import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmtDate } from '../api';
import StatusBadge from '../components/StatusBadge';

function Bars({ rows, color }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  if (!rows.length) return <p className="muted">No data yet.</p>;
  return (
    <div className="hbars">
      {rows.map((r) => (
        <div key={r.label} className="bar-row wide">
          <span>{r.label}</span>
          <div className="bar"><i style={{ width: `${(r.count / max) * 100}%`, background: color }} /></div>
          <b>{r.count}</b>
        </div>
      ))}
    </div>
  );
}

function Overview() {
  const [s, setS] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { api.get('/admin/stats').then((r) => setS(r.data)).catch((e) => setError(errMsg(e))); }, []);
  if (error) return <div className="alert error">{error}</div>;
  if (!s) return <p className="muted">Loading analytics...</p>;
  const t = s.totals;
  return (
    <>
      <div className="stats">
        <div className="stat big"><b>{s.recoveryRate}%</b><span>of reported items recovered</span></div>
        <div className="stat"><b>{t.items}</b><span>items posted ({t.lost} lost, {t.found} found)</span></div>
        <div className="stat"><b>{t.returned}</b><span>returned to owners</span></div>
        <div className="stat"><b>{t.pendingClaims}</b><span>claims waiting for review</span></div>
        <div className="stat"><b>{t.users}</b><span>registered users</span></div>
      </div>
      <div className="two">
        <section className="panel"><h2>Where things get lost</h2><Bars rows={s.topLostLocations} color="var(--lost)" /></section>
        <section className="panel"><h2>Items by category</h2><Bars rows={s.byCategory} color="var(--found)" /></section>
      </div>
    </>
  );
}

function Claims() {
  const [status, setStatus] = useState('PENDING');
  const [claims, setClaims] = useState(null);
  const [notes, setNotes] = useState({});
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.get('/admin/claims', { params: { status } }).then((r) => setClaims(r.data.claims)).catch((e) => setError(errMsg(e)));
  }, [status]);
  useEffect(() => { setClaims(null); load(); }, [load]);

  const review = async (claim, decision) => {
    setError('');
    try {
      await api.put(`/admin/claims/${claim._id}/review`, { status: decision, adminComment: notes[claim._id] || '' });
      load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  // group claims by item so competing proofs sit side by side
  const groups = [];
  (claims || []).forEach((c) => {
    let g = groups.find((x) => x.item._id === c.itemId._id);
    if (!g) groups.push((g = { item: c.itemId, claims: [] }));
    g.claims.push(c);
  });

  return (
    <>
      <div className="seg" role="group" aria-label="Claim status">
        {['PENDING', 'APPROVED', 'REJECTED'].map((s) => <button key={s} className={status === s ? 'on' : ''} onClick={() => setStatus(s)}>{s === 'PENDING' ? 'Pending' : s === 'APPROVED' ? 'Approved' : 'Rejected'}</button>)}
      </div>
      {error && <div className="alert error" role="alert">{error}</div>}
      {!claims ? <p className="muted">Loading claims...</p> : groups.length === 0 ? <div className="empty"><p>No {status.toLowerCase()} claims.</p></div> : groups.map(({ item, claims: list }) => (
        <section key={item._id} className="panel">
          <div className="claim-item">
            <div>
              <Link to={`/items/${item._id}`}><strong>{item.title}</strong></Link>
              <div className="muted">{item.type === 'LOST' ? 'Lost' : 'Found'} at {item.location} on {fmtDate(item.date)}, posted by {item.postedBy?.name} ({item.postedBy?.rollNo || item.postedBy?.email})</div>
              <div>{item.description}</div>
              {item.privateNote && <div className="alert info"><strong>Poster’s private detail:</strong> {item.privateNote}</div>}
            </div>
            <StatusBadge status={item.status} />
          </div>
          <div className="claims-compare">
            {list.map((c) => (
              <article key={c._id} className="claim">
                <strong>{c.claimantId?.name}</strong>
                <div className="muted">{c.claimantId?.rollNo || c.claimantId?.email}{c.claimantId?.department ? `, ${c.claimantId.department}` : ''}</div>
                <p><b>Proof:</b> {c.proof}</p>
                {c.reason && <p><b>Explanation:</b> {c.reason}</p>}
                {c.status === 'PENDING' ? (
                  <>
                    <textarea rows={2} placeholder="Comment (required when rejecting)" value={notes[c._id] || ''} onChange={(e) => setNotes({ ...notes, [c._id]: e.target.value })} />
                    <div className="actions">
                      <button className="btn small" onClick={() => review(c, 'APPROVED')}>Approve claim</button>
                      <button className="btn ghost danger small" onClick={() => review(c, 'REJECTED')}>Reject claim</button>
                    </div>
                  </>
                ) : (<><StatusBadge status={c.status} />{c.adminComment && <p className="muted">{c.adminComment}</p>}</>)}
              </article>
            ))}
          </div>
        </section>
      ))}
    </>
  );
}

function Items() {
  const [filters, setFilters] = useState({ type: '', status: 'ALL', q: '' });
  const [data, setData] = useState({ items: [], pages: 1 });
  const [page, setPage] = useState(1);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.get('/items', { params: { ...filters, page, limit: 20 } }).then((r) => setData(r.data)).catch((e) => setError(errMsg(e)));
  }, [filters, page]);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  const act = async (fn) => { try { await fn(); load(); } catch (e) { setError(errMsg(e)); } };
  const del = (i) => window.confirm(`Delete "${i.title}" and its claims?`) && act(() => api.delete(`/items/${i._id}`));

  return (
    <>
      <div className="filters">
        <input type="search" placeholder="Search items" value={filters.q} onChange={(e) => { setPage(1); setFilters({ ...filters, q: e.target.value }); }} aria-label="Search items" />
        <select value={filters.type} onChange={(e) => { setPage(1); setFilters({ ...filters, type: e.target.value }); }} aria-label="Type"><option value="">Lost and found</option><option value="LOST">Lost</option><option value="FOUND">Found</option></select>
        <select value={filters.status} onChange={(e) => { setPage(1); setFilters({ ...filters, status: e.target.value }); }} aria-label="Status">
          <option value="ALL">Any status</option><option value="OPEN">Open</option><option value="PENDING_CLAIM">Claim under review</option><option value="APPROVED">Claim approved</option><option value="RETURNED">Returned</option>
        </select>
      </div>
      {error && <div className="alert error" role="alert">{error}</div>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Item</th><th>Type</th><th>Location</th><th>Posted by</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {data.items.map((i) => (
              <tr key={i._id}>
                <td><Link to={`/items/${i._id}`}>{i.title}</Link></td>
                <td>{i.type === 'LOST' ? 'Lost' : 'Found'}</td>
                <td>{i.location}</td>
                <td>{i.postedBy?.name}</td>
                <td><StatusBadge status={i.status} /></td>
                <td className="actions">
                  {i.status === 'APPROVED' && <button className="btn small" onClick={() => act(() => api.put(`/admin/items/${i._id}/mark-returned`))}>Mark returned</button>}
                  <button className="btn ghost danger small" onClick={() => del(i)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data.pages > 1 && (
        <div className="pager">
          <button className="btn ghost small" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span className="muted">Page {page} of {data.pages}</span>
          <button className="btn ghost small" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </>
  );
}

function Users() {
  const [q, setQ] = useState('');
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');
  const load = useCallback(() => {
    api.get('/admin/users', { params: { q } }).then((r) => setUsers(r.data.users)).catch((e) => setError(errMsg(e)));
  }, [q]);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  const act = async (fn) => { setError(''); try { await fn(); load(); } catch (e) { setError(errMsg(e)); } };

  return (
    <>
      <div className="filters"><input type="search" placeholder="Search name, email or roll number" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search users" /></div>
      {error && <div className="alert error" role="alert">{error}</div>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Roll no.</th><th>Department</th><th>Points</th><th>Role</th><th></th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td><td>{u.email}</td><td>{u.rollNo || '-'}</td><td>{u.department || '-'}</td><td>{u.points}</td>
                <td>
                  <select value={u.role} aria-label={`Role for ${u.name}`} onChange={(e) => act(() => api.put(`/admin/users/${u._id}/role`, { role: e.target.value }))}>
                    <option value="student">Student</option><option value="faculty">Faculty</option><option value="admin">Admin</option>
                  </select>
                </td>
                <td><button className="btn ghost danger small" onClick={() => window.confirm(`Delete ${u.name} and all their posts?`) && act(() => api.delete(`/admin/users/${u._id}`))}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

const TABS = { overview: ['Overview', Overview], claims: ['Claims', Claims], items: ['Posts', Items], users: ['Users', Users] };

export default function Admin() {
  const [tab, setTab] = useState('overview');
  const Active = TABS[tab][1];
  return (
    <>
      <div className="page-head"><h1>Admin dashboard</h1></div>
      <div className="seg" role="tablist">
        {Object.entries(TABS).map(([k, [label]]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>)}
      </div>
      <div className="tab-body"><Active /></div>
    </>
  );
}
