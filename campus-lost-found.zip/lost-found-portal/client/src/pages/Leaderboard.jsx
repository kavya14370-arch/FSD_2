import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';

export default function Leaderboard() {
  const { user } = useAuth();
  const [leaders, setLeaders] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/leaderboard').then((r) => setLeaders(r.data.leaders)).catch((e) => setError(errMsg(e)));
  }, []);

  return (
    <div className="narrow">
      <h1>Helpful finders</h1>
      <p className="muted">Earn 10 points each time an item you found is handed back to its owner and both of you confirm it.</p>
      {error && <div className="alert error" role="alert">{error}</div>}
      {!leaders ? <p className="muted">Loading...</p> : leaders.length === 0 ? (
        <div className="empty"><p>No returns yet. Be the first on the board by posting something you found.</p></div>
      ) : (
        <ol className="board">
          {leaders.map((l, i) => (
            <li key={l._id} className={`${i < 3 ? 'top' : ''} ${l._id === user._id ? 'me' : ''}`}>
              <span className="rank">{i + 1}</span>
              <div className="who"><strong>{l.name}{l._id === user._id ? ' (you)' : ''}</strong><span className="muted">{l.department}{l.year ? `, year ${l.year}` : ''}</span></div>
              <span className="muted">{l.returns} {l.returns === 1 ? 'return' : 'returns'}</span>
              <strong className="pts">{l.points} pts</strong>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
