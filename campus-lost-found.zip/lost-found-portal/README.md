# Campus Lost & Found Portal

React (Vite) + Node/Express + MongoDB. Students and faculty report lost or found items, get automatic match suggestions, claim items with proof, and admins verify claims. Finders earn points when a return is confirmed.

## Run it

Requires Node 18+ and a running MongoDB (local or Atlas).

```bash
# 1. API
cd server
npm install
cp .env.example .env   # then set MONGO_URI and a long random JWT_SECRET
npm run seed        # creates admin@campus.edu / Admin@12345 plus demo users (asha@campus.edu, ravi@campus.edu, password: student123)
npm run dev         # http://localhost:5000

# 2. Web app (second terminal)
cd client
npm install
npm run dev         # http://localhost:5173  (proxies /api and /uploads to :5000)
```

Change the seeded admin password before any real deployment.

## Workflow

1. Register or log in. Self-registration creates students or faculty only; admins come from the seed script or from another admin changing a role.
2. **Report** a lost or found item (photo optional). The server runs the matching algorithm immediately and the item page lists the best candidates.
3. **Claim**. On a FOUND post the claimant says "this is mine"; on a LOST post the claimant says "I found this". Both submit proof.
4. **Admin review**. Claims are grouped by item so competing proofs sit side by side, next to the poster's optional private detail. Approving one claim auto-rejects the others and opens a handover. Rejections need a comment.
5. **Handover**. Owner and finder each press "Confirm handover". When both have, the item becomes RETURNED and the finder earns 10 points.

Item status flow: `OPEN -> PENDING_CLAIM -> APPROVED -> RETURNED` (rejecting the last pending claim returns it to `OPEN`).

## Match score (`server/utils/matching.js`)

| Factor | Weight | How it is scored |
|---|---|---|
| Category | 25 | same category = full |
| Location | 25 | same location = full |
| Date | 20 | within 1 day = full, fading linearly to 0 at 14 days |
| Color | 15 | identical = full; any shared color word ("dark blue" vs "blue") = 70% |
| Keywords | 15 | shared words in title + description, as a share of the shorter text (stop words removed) |

Only opposite-type, open items from other users are compared. Suggestions below 40% are hidden (`MATCH_THRESHOLD` in `config/constants.js`).

## API

All routes except register/login need `Authorization: Bearer <token>`.

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create student/faculty account |
| POST | `/api/auth/login` | Log in, returns JWT |
| GET | `/api/auth/me` | Current user |
| GET | `/api/items` | List/search: `type, category, location, status, q, page, limit` |
| POST | `/api/items` | Report item (multipart, field `image`), returns `{ item, matches }` |
| GET | `/api/items/mine` | My posts |
| GET | `/api/items/:id` | Item detail (private note only for poster/admin) |
| GET | `/api/items/:id/matches` | Match suggestions (poster/admin) |
| PUT | `/api/items/:id` | Edit own post while OPEN |
| DELETE | `/api/items/:id` | Delete own post (before approval) or any post as admin |
| POST | `/api/claims` | Send claim `{ itemId, proof, reason }` |
| GET | `/api/claims/mine` | My claims |
| DELETE | `/api/claims/:id` | Withdraw a pending claim |
| GET | `/api/returns/mine` | My handovers |
| PUT | `/api/returns/:id/confirm` | Confirm handover (owner or finder) |
| GET | `/api/leaderboard` | Top finders |
| GET | `/api/admin/stats` | Totals, recovery rate, top lost locations, categories |
| GET | `/api/admin/users` | Search users |
| PUT | `/api/admin/users/:id/role` | Change role |
| DELETE | `/api/admin/users/:id` | Delete user and their posts |
| GET | `/api/admin/claims?status=` | Claims with item, poster and claimant details |
| PUT | `/api/admin/claims/:id/review` | `{ status: APPROVED/REJECTED, adminComment }` |
| PUT | `/api/admin/items/:id/mark-returned` | Override when handover happened offline |

## Structure

```
server/  config/ models/ controllers/ routes/ middleware/ utils/ seed.js server.js
client/  src/{api.js, context/, components/, pages/, styles.css}
```

## Notes and decisions

- Passwords are hashed with `bcryptjs` (same bcrypt algorithm, 12 rounds, no native build step). Swap to `bcrypt` if you prefer; the API is identical.
- Fields added beyond your schemas: `User.points`, `Item.time`, `Item.privateNote` (hidden from everyone but poster and admins), `Return.claimId` and `Return.pointsAwarded` (guards against awarding points twice).
- Uploads are stored on local disk in `server/uploads` (JPG/PNG/WebP, 5 MB). Use S3 or Cloudinary if you deploy to a host with ephemeral storage.
- The JWT is kept in `localStorage`, which is fine for a campus app but exposed to XSS; use httpOnly cookies if you harden this.
- Production: build with `npm run build` in `client`, set `VITE_API_URL` and `VITE_API_ORIGIN` if the API is on another origin, and set `CLIENT_URL` on the server for CORS.
- No automated tests are included yet. The matching module is pure and a good first target.
